import { MiddlewareConsumer, Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';
import { ProductController } from './Product/product.controller';
import { ProductService } from './Product/product.service';
import { ProductModule } from './Product/product.module';
import { AuthorModule } from './Author/author.module';
import { BasketController } from './Basket/basket.controller';
import { BasketModule } from './Basket/basket.module';
import { BasketService } from './Basket/basket.service';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { JwtModule } from '@nestjs/jwt';
import { PrismaModule } from './prisma/prisma.module';
import { UsersModule } from './users/users.module';
import { options } from './auth/config';
import { OrderModule } from './order/order.module';
import { ReservationModule } from './reservation/reservation.module';
import { StatisticsModule } from './statistics/statistics.module';
import { PaymentModule } from './payment/payment.module';
import { PrismaService } from './prisma/prisma.service';
import { TokenMiddleware } from './middleware/TokenMiddleware';
import { ChatModule } from './chat/chat.module';




@Module({
  imports: [ServeStaticModule.forRoot({
    rootPath: 'D:\\6sem\\vinyl-shop\\wwwroot',
  }),
  ConfigModule.forRoot({ isGlobal: true }), 
  ProductModule,
  AuthorModule,
  BasketModule,
  PrismaModule,
  AuthModule,
  UsersModule,
  ChatModule,
  JwtModule.registerAsync(options()),
  OrderModule,
  ReservationModule,
  StatisticsModule,
  PaymentModule],
  controllers: [AppController, ProductController, BasketController],
  providers: [AppService, ProductService, BasketService, PrismaService],
})
export class AppModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(TokenMiddleware).forRoutes(
      { path: 'Basket/:erorr?', method: 0 },
      { path: 'Basket/AddToCart/:productId', method: 1 },
      { path: 'Basket/RemoveFromCart/:productId', method: 1 },
      { path: 'Author/Add', method: 0 },
      { path: 'Author/EditAuthor', method: 0 },
      { path: 'Author/EditAuthor', method: 1 },
      { path: 'Author/Delete', method: 1 },
      { path: 'order/AdminStatistics', method: 0 },
      { path: 'order/:error?', method: 0 },
      { path: 'order/UpdateOrderStatus', method: 1 },
      { path: 'order/makeOrder', method: 1 },

      { path: 'Product/Search', method: 0 },
      { path: 'Product/Add', method: 0 },
      { path: 'Product/Add', method: 1 },
      { path: 'Product/EditProduct', method: 0 },
      { path: 'Product/EditProduct', method: 1 },
      { path: 'Product/Delete', method: 1 },
      { path: 'Product/:CurrentCollection?', method: 0,},

      { path: 'api/cart', method: 0 },
    );
  }
}
