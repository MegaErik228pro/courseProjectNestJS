import { Controller, Get, Post, Render, Req } from "@nestjs/common";
import { AppService } from "./app.service";
import { Response, Request } from "express";
import { JwtService } from "@nestjs/jwt";

@Controller()
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly jwtService: JwtService,
  ) {}

  @Get()
  @Render("index")
  index(): string {
    return;
  }

  @Post()
  async CurrentUser(@Req() request: Request) {
    try {
      const accessToken = request.cookies["access_token"];
      const decodedToken: any = this.jwtService.verify(accessToken);
      const userId = decodedToken.id;
      // console.log(decodedToken.roles);
      return decodedToken;
    } catch {
      return "un";
    }
  }
}
