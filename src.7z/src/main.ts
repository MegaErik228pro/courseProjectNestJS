import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import  { join } from 'path';
import { NestExpressApplication } from '@nestjs/platform-express';
import * as express from 'express';
const session = require('express-session');
import * as cookieParser from 'cookie-parser';
import * as fs from 'fs';

import { PrismaService } from './prisma/prisma.service';
import { ValidationPipe } from '@nestjs/common';

const httpsOptions = {
  key: fs.readFileSync('./secrets/cert.key'),
  cert: fs.readFileSync('./secrets/cert.crt'),
};
async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule, {httpsOptions});
  
  app.setBaseViewsDir('D:\\6sem\\vinyl-shop\\views');
  console.log(__dirname);
  //app.enableCors();
  //const prismaService = app.get(PrismaService);
  //await prismaService.enableShutdownHooks(app);
  app.useGlobalPipes(new ValidationPipe())
  app.setViewEngine('ejs');
  app.use(express.json()); // Используем middleware для парсинга JSON данных
  app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true
  }));
  app.use(cookieParser());

  await app.listen(3000);
}
bootstrap();
